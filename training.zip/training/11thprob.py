'''input-3
4 5 2
1 2 3
6 7 4
output-
2
2nd sublist has highest sum'''
'''n=int(input())
l=[]
s,d=0,0
for i in range(n):
    a=l.append(list(map(int,input().split(","))))

for i in range(l):
    s=sum(i)
    if s>d:
        d=s
    print(i)'''
n=int(input())
nestList = [list(map(int,input().split())) for i in range(n)]
maxm,total=0,0
for ind,data in enumerate(nestList):
    if total < sum(data):
        total = sum(data)
        maxm = ind
print(maxm)
        
    

