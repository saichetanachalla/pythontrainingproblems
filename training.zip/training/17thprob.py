import string
'''print(string.ascii_letters)
print(string.digits)
print(string.hexdigits)'''
n=input()
if n in string.digits:
    print("true")
else:
    print("false")