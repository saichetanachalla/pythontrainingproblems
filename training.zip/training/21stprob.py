'''Rotate a given string in the specified direction
by specified magnitude. After each rotaion make a note of the
sample input:
carrace
3
L 2
R 2
L 3
output:
no
exp-after applying all rotations the firstcharstring will be
"rcr" which is not anagram of any sub string of original string "carrace"
rraceca
carrace
racecar'''
data=input()
rot=int(input())
res=""
for i in range(rot):
    di,mag=input().split()
    if di.upper() == "L":
        res+=(data[int(mag):]+data[:int(mag)])[0]
    elif di.upper() == 'R':
        res+=(data[:int(mag)]+data[int(mag):])[0]
subL=[data[i:i+rot] for i in range(len(data)-rot+1)]
for subele in subL:
    if sorted(subele) == sorted(res):
        print("yes")
        break
    else:
        print("no")

    