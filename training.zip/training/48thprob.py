#codeforces 136A
n=int(input())
l=list(map(int,input().split()))[:n]
r=[]
for i in range(len(l)):
    c=i+1
    for j in range(len(l)):
        if c==l[j]:
            r.append(j+1)
            
print(*r)           
                   
        