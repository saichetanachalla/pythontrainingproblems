#a tuple is given remove the given index's element 
n=tuple(map(int,input().split(",")))
i=int(input())
a=n[:i]
b=n[i+1:]
c=a+b
print(c)
