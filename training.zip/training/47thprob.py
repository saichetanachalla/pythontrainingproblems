def totalSum(self,root):
    if root is None:
        return 0
    else:
        leftSum = totalSum(root.left)
        rightSum = totalSum(root.right)
        return root.data + leftSum + rightSum
    
def treeMax(self,root):
    if root is None:
        return 0
    else:
        leftSum = totalSum(root.left)
        rightSum = totalSum(root.right)
        return max(root.data,leftSum,rightSum)
    
def treeHeight(self,root):
    if root is None:
        return 0
    else:
        leftHeight = treeHeight(root.left)
        rightheight = treeHeight(root.right)
        return 1 + max(leftHeight, rightHeight)

def ele(self,root,el):
    if root is None:
        return False
    else:
        ileft=ele(root.left, el)
        iright=ele(root.right, el)
        return root.data == el or ileft or iright
            
def reverseTree(self,root):
    if root is None:
        return
    else:
        reverseTree(root.left)
        reverseTree(root.right)
        root.left, root.right = root.right, root.left
        