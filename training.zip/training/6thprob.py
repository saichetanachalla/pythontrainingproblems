s=int(input())
n=[i**3 for i in range(1,s+1) if (i**3)%2==0]
print(n)