def permute(List,l,r):
    if l==r:
        print((List))
    else:
        for i in range(l,r):
            List[l],List[i]=List[i],List[l]
            permute(List,l+1,r)
            List[l],List[i]=List[i],List[l]
data={1,2,3}
n=len(data)
permute(list(data),0,n)
