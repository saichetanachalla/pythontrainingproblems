#counting the length of most recurring number in a list
n=list(map(int,input().split(",")))
c,d=0,0
for i in range(len(n)):
    if n[i]==1:
        c+=1
        if c>d:
            d=c
    else:
        c=0
print(d)
        