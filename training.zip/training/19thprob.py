n,a=input(),input()
print("This is {0} and {1}".format(n,a))
