l1=[6,5,2,7,9,3]
l2=[2,4,9,6,7,4]
res=[]
def rev_sum(i):
    if i>=len(l1) and i+1>=len(l2):
        return
    if i>=len(l1) and i+1<=len(l2):
        res.extend(l2[i+1::2])
        return
    if i<=len(l1) and i+1>=len(l2):
        res.extend(l1[i::2])
        return
    res.append(l1[i]+l2[i+1])
    rev_sum(i+2)
rev_sum(0)
print(res)
'''output-[10, 8, 13]
input-[1,2,3]
[4,5]
output-[6, 3]'''