#i-abacabaabacabaa  codeforces 81 A
#o-a  removing all consecutive elements and checking again after a iteration  use stacks
s=input()
l=[]
for i in s:
    if l and l[-1]==i:
        l.pop()
    else:
        l.append(i)
print(''.join(l))
    