#lexicographical order for numbers
d=int(input())
res=[str(i) for i in range(1,d+1)]
res.sort()
print(list(map(int,res)))#time limit will exceed for this solution
