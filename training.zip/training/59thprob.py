# print kth factor
'''n,k=map(int,input().split())
l=[]
for i in range(1,n):
    if n%i==0:
        l.append(i)
print(l[k])'''
def fdivisors(n, i=1, l=[]):
    if i >= n:
        return l
    if n % i == 0:
        l.append(i)
    return fdivisors(n, i + 1, l)

def get_kth_divisor(n, k):
    d = fdivisors(n)
    return d[k] if k < len(d) else None

# Read input
n, k = map(int, input().split())

# Get the k-th divisor
result = get_kth_divisor(n, k)
print(result)
