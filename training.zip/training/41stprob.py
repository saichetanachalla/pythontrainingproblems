t=int(input())
for i in range(t):
    l=int(input())
    li=list(map(int,input().split( )))[:l]
    if len(li)<=2:
        print(''.join(map(str, li)))
        break
    '''if li[-1]>li[-2]:
        li[-1],li[-2]=li[-2],li[-1]
    print(int(''.join(map(str,li))))
    else:
        result = [-1] * len(li)  # Initialize the result list with -1
        stack = []  # Stack to keep track of elements for which we haven't found the next greater element
            
        for i in range(len(li)):
                # While stack is not empty and the current element is greater than the stack's top element
            while stack and li[i] > li[stack[-1]]:
                index = stack.pop()
                result[index] = li[i]
                stack.append(i)  # Add current element index to stack
            
            # Convert the result list to a single number and print
        print(int(''.join(map(str, result))))'''
    index=l-1
    for i in range(l-1,0,-1):
        if li[i] > li[i-1]:
            li[i],li[i-1]=li[i-1],li[i]
            index=i
            break
    res=[str(ele) for ele in (li[:index] + (li[index:])[::-1])]
    print(''.join(res))
   
    
    
        
        
        