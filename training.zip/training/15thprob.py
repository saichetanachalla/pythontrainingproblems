#power of 6-given an integer n return true if it is a power of 6 else false
'''num=int(input())
while num!=1:
    if num % 6 == 0:
        num//=6
    else:
        print("false")
else:
    print("true")'''
#basic recursion program
def power(n):
    if n<=0:
        return
    power(n-1)
    print(n,end=" ")     
power(5)