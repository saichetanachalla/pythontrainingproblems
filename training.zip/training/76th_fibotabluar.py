'''def fibo(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        table=[0]*(n+1)
        table[0]=0
        table[1]=1
        for i in range(2,n+1):
            table[i]=table[i-1]+table[i-2]
        return table[n]

print(fibo(5))'''

''' memorization
def fibo(n,cache={}):
    if n in cache:
        return cache[n]
    if n==0:
        res=0
    elif n==1:
        res=1
    else:
        res=fibo(n-1)+fibo(n-2) nc'''

def fibo(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        p2=0
        p1=1
        for i in range(2,n+1):
            res=p2+p1
            p2,p1=p1,res  
        return res

print(fibo(5))#O(1) space complexity
    