def palind(n):
    orig=n
    res=0
    while n>0:
        r=n%10
        res=(res*10)+r
        n=n//10
    if orig==res:
        return "yes"
    else:
        return "no"
n=int(input())
print(palind(n))

    

