tCase=int(input())
for i in range(tCase):
    n,m=map(int,input().split())
    x1,y1,x2,y2=map(int,input().split())
    a= 4 - (x1 == 1 or x1 == n) - (y2==1 or y1==m)
    b= 4 - (x2 == 1 or x2 == n) - (y2==1 or y2==m)
    if a<b:
        print(a)
    else:
        print(b)
    