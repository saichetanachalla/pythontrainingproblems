#codeforces 4a
n=int(input())
if n%2==0 and n>2:
    print("Yes")
else:
    print("no")