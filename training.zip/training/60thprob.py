#true if odd indexes->float even-int
'''l = list(input().split())
c= False

for i in range(len(l)):
    if (i % 2 == 0 and isinstance(int(l[i]), int)) and (i % 2 != 0 and isinstance(float(l[i]), float)):
        c= True
    else:
        c=False

if c:
    print("True")
else:
    print("False") wrong'''

nl=list(input().split())
for i in range(len(nl)):
    if i % 2==0:
        if '.' not in str(nl[i]):
            print("False")
            break
    else:
       # if nl[i].is_integer() == 'int':
       if '.' not in str(nl[i]):
           print('False')
           break
else:
    print('True')
           
            
        
            
