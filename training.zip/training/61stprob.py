'''given an n*n matrix of 0's and 1's where all 1's in each row come before all 0's task
is to find the efficient way to return the row with the max no.of 0's.
input:
1
{{1,1,1,1},{1,1,0,0},{1,0,0,0},{1,1,0,0}}
output:
2'''
t=int(input())
f=[]
for i in range(t):
    l=list(map(int,input().split()))
    f.append(l)
    for j in range(len(l)-1):
        k=list(map(int,input().split()))  
        f.append(k)
c=0
for i in range(len(f)):
    if c < f[i].count(0):
        c=f[i].count(0)
        c=i
print(c)