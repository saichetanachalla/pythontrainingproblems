s=int(input())
n,k=map(int,input().split())
l=list(map(int,input().split()))[:n]
'''l.sort()
new=[]
for i in range(len(l)):
    r=abs(max(l)-k)
    if not new:
        new.append(i+r)
    del new
print(new)'''
print(abs(min(l)-k))
