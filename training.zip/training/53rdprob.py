#codeforces 78A
s1=input().strip()
s2=input().strip()
s3=input().strip()
vowels=['a','e','i','o','u']
c,d,e=0,0,0
for i in s1:
    if i in vowels:
        c+=1
for i in s2:
    if i in vowels:
        d+=1
for i in s3:
    if i in vowels:
        e+=1
if c==5 and d==7 and e==5:
    print("Yes")
else:
    print("No")
 