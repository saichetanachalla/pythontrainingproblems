l=list(map(int,input().split()))
while len(l) > 1:
    l.sort()
    r=abs(l.pop() - l.pop())
    if r!=0:
        l.append(r)
print(l[0])