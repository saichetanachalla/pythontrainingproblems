n=2
m=3
'''n,m=m,n'''
'''a = a + b
b = a - b
a = a - b'''
n = n ^ m
m = n ^ m
n = n ^ m

print(n,m)