'''def rev_add(l1,l2,f,s):
    r=l2[::-1]
    if f>=len(l1):
        return l2[s:]
    if s>=len(r):
        return l1[f:]
    sum_lists=l1[f]+r[s]
    return [sum_lists]+rev_add(l1,r,f+1,s+1)

l1=[1,2,3]
l2=[5,4]
print(rev_add(l1,l2,f=0,s=0)) nc'''

l1=[6,5,2,7,9,3]
l2=[2,4,9,6,7]
res=[]
def rev_sum(l,r):
    if l==len(l1) and r!=-1:
        res.extend(l2[r::-1])
        r=-1
        return
    if l!=len(l1) and r==-1:
        res.extend(l1[l:])
        l=0
        return
    if l==len(l1) and r==-1:
        return
    res.append(l1[l]+l2[r])
    rev_sum(l+1,r-1)
rev_sum(0,len(l2)-1)
print(res)
#output-[13, 11, 11, 11, 11, 3]
