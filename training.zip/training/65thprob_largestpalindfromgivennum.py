'''def palind(n):
    orig=n
    res=0
    while n>0:
        r=n%10
        res=(res*10)+r
        n=n//10
    if orig==res:
        return "yes"
    else:
        return "no"'''
'''def palindrome(s):
    if len(s) <= 1:
        return True
    if s[0] != s[-1]:
        return False
    return palindrome(s[1:-1])'''

'''if result:
    print("True")
else:
    print( "False")'''
    
'''def largestpal(n):
    maxL=0
    lP=''
    for i in range(len(n)):
        for j in range(i+1,len(n)+1):
            substr=n[i:j]
            if palindrome(substr):
                if len(substr) > maxL and len(substr) > maxL:
                    maxL=len(substr)
                    lP=substr
    return lP

n=input()
print(largestpal(n))'''
def is_palindrome(s):
    return s == s[::-1]

def largestpal(n):
    max_len = 0
    longest_palindrome = ''
    for i in range(len(n)):
        for j in range(i + 1, len(n) + 1):
            substr = n[i:j]
            if is_palindrome(substr) and len(substr) > max_len:
                max_len = len(substr)
                longest_palindrome = substr
    return longest_palindrome

n = input()
print(largestpal(n))
