#first and last element swap
n=list(input().split())
print(n)
n[0],n[-1]=n[-1],n[0]
print(n)