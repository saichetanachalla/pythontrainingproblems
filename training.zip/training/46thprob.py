#lexico string
'''jill jumbled up the order of the letters in dictionary. Jack uses the list to find the smallest lexicographical string
that can be made out of this new order. You r given a string P that denotes the new order of letters in eng dict print smallest lexi string made from given string
'''
n=int(input())
li=[]
for i in range(n):
    s=input()
    p=input()
    l=''
    for i in s:
        if i in p:
            l+=i
    li.append(l)
for j in li:
    print(j)
            
            