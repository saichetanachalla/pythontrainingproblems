#krishna candies problem
'''input                      output
1                             19
4
1 2 3 4

1                             34
5
1 2 3 4 5'''
n=int(input())
s=int(input())
l=list(map(int,input().split()))[:s]
totS=l[0]
totTime=0
for i in l[1:]:
    totS+=i
    totTime+=totS
print(totTime)