#generate a number from given string
import string
n=input()
a=""
for i in n:
    if i in string.digits:
        a+=i
print(int(a))
    