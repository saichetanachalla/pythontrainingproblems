def sum_of_all_ele(n):
    if n==[]:
        return 0
    return n[i]+sum_of_all_ele(i+1)
    '''else:
        i,s=0,0
        while i<len(n):
            s+=n[i]
            i+=1
        return s'''
n=list(map(int,input().split()))
print(sum_of_all_ele(n))
'''15 3 6 12 8 5
49'''
