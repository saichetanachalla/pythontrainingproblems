#peak element - an element which is greater than its adjacent neighbours
'''input-[1,2,3,4,5,6,2,1]
output-6'''
def peak(a):
    if a[0]>a[1]:
        return 0
    if a[-1]>a[-2]:
        return len(a)-1
    for i in range(1,len(a)-2):
        if a[i]>a[i-1] and a[i]>a[i+1]:
            return i
           
a=list(map(int,input().split()))
print(peak(a))

