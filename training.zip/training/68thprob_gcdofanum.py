def gcd(n):
    l=[]
    for i in range(2,n//2+1):
        if n%i==0:
            l.append(i)
    if l==[]:
        return n
    else:
        return max(l)
     
n=int(input())
print(gcd(n))