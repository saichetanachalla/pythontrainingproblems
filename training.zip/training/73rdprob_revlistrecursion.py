'''def revlis(a,s,e):
    if s>=e:#when left pointer crosses right pointer
        return a
    a[s], a[e] = a[e],a[s]
    return revlis(a,s+1,e-1)
a=[1,2,3,4,5]
s=0
e=len(a) - 1
rl=revlis(a,s,e)
print(rl)'''
    
def permute(List,l,r):
    if l==r:
        print(List)
    else:
        for i in range(l,r):
            List[l],List[i]=List[i],List[l]
            permute(List,l+1,r)
            List[l],List[i]=List[i],List[l]
d={1,2,3}
n=len(d)
print(list(d),0,n)