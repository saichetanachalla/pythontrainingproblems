#codeforces 460C
n,m,w=map(int,input().split())
l=list(map(int,input().split()))[:n]
minh=min(l)
print(minh+abs(m-w))
'''for i in range(m-1):
    for j in range:'''
        
        
