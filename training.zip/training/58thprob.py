fib=[0,1]
def fibo(n):
    if n < 0:
        print("Incorrect number")
    elif n < len(fib):
        return fib[n]
    fib.append(fibo(n-1) +fibo(n-2))
    return fib[n]

print(fibo(int(input())))