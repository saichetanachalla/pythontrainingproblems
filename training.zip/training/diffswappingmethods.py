n=2
m=3
'''n,m=m,n'''
'''n = n + m
m = n - m
n = n - m'''
n = n ^ m
m = n ^ m
n = n ^ m

print(n,m)