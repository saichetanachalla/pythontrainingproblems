#palindrome program using stacks
'''strData=input()
n=len(strData)
half=n//2
stack=[strData[:half]]
if n%2==0:
    for i in strData[half:]:
        if i!=stack.pop():
            print("Not a palindrome")
            break
    else:
        print("palindrome")
else:
    for i in strData[half+1:]:
        if i!=stack.pop():
            print("not a palindrome")
    else:
        print("palindrome")'''
class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

def is_palindrome(string):
    stack = Stack()

    for char in string:
        stack.push(char)

    # Check characters from stack with the original string
    for char in string:
        if char != stack.pop():
            return False

    return True

input_string = "radar"
print(f"Is '{input_string}' a palindrome? {is_palindrome(input_string)}")

input_string = "hello"
print(f"Is '{input_string}' a palindrome? {is_palindrome(input_string)}")
