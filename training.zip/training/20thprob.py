#remove consecutive duplicates
n=input()
r=""
r+=n[0]
for i in range(1,len(n)):
    if n[i-1]!=n[i]:
        r+=n[i]
print(r)
        
    
    
        
