#printing the sum of evenelements from l1 and odd element from l2 eg:output for below res=[28,20] 28->(6+9)+(6+7) 20->(2+9)+(2+7)
def evenodd_sum(l1,l2,i=0,j=0,res=None):
    if res==None:
        res = []
    if i>=len(l1):
        return res
    if l1[i]%2!=0:
        return evenodd_sum(l1,l2,i+1,j,res)
    if j<len(l2):
        if l2[j]%2!=0:
            res.append(l1[i]+l2[j])
        return evenodd_sum(l1,l2,i,j+1,res)
    else:
        return evenodd_sum(l1,l2,i+1,0,res)
l1=[6,5,2,7,9,3]
l2=[2,4,9,6,7,4]
print(evenodd_sum(l1,l2))#solve
