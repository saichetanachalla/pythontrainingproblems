#input a list and sort the elements in the list based on its length
n=list(input().split())
print(sorted(n,key=len))
        
        
        
          