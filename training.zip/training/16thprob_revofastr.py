#print the reverse of the string
'''def stri(n):
    if len(n)<=1:
        return n
    return stri(n[1:]) + n[0]
    
print(stri("have a good day"))'''
def revs(n):
    if n=="":
        return n
    return n[-1]+revs(n[:-1])

print(revs("have a good day"))

    