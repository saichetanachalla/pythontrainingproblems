#STPAR-street parade problem codeforces
'''Sample input:
5
5 1 2 4 3 
0

Sample output:
yes'''
n=int(input())
l=list(map(int,input().split( )))[:n]
s=[]
res=[]
for i in range(0,len(l)-1):
    if l[i] > l[i+1]:
        s.append(l[i])
    else:
        res.insert(0,l[i])
res.insert(0,l[-1])
res=s+res
if sorted(l,reverse=True)==res:
    print("Yes")
else:
    print("no")