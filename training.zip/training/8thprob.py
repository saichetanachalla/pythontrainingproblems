b=list(map(int,input().split()))
k=int(input())
print(max(b)-k)