# remove an empty tuple from list of tuples
d=[(),('',),(1,2,3),(5,)]
d=[i for i in d if i and all(i)]
print(d)
