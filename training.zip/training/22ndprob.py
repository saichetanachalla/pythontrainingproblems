from collections import deque
data=input()
qstr = deque(data)
rot=int(input())
res=""
for i in range(rot):
    di,mag=input().split()
    mag=int(mag)
    if di =='l' or di=='L':
        qstr.rotate(-mag)
        res+=qstr[0]
    elif di=='r' or di=='R':
        qstr.rotate(mag)
        res+=qstr[0]
        
subl=[qstr[i:i+rot] for i in range(0,len(qstr)-rot+1)]
for subele in subl:
    if sorted(subele)==sorted(res):
        print("Yes")
        break
else:
    print("no")
#error