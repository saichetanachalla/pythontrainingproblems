'''There are N houses built in a line, each of which contains some value in it.
A thief is going to steal the maximum value of these houses, but he can’t steal in two adjacent houses
because the owner of the stolen houses will tell his two neighbors left and right sides.
The task is to find what is the maximum stolen value.
Input: hval[] = {6, 7, 1, 3, 8, 2, 4}
Output: 19
Explanation: The thief will steal 6, 1, 8 and 4 from the house.

Input: hval[] = {5, 3, 4, 11, 2}
Output: 16
Explanation: Thief will steal 5 and 11
9,2,1,40,6,9 o:58(40,9,9)'''
n=list(map(int,input().split(",")))
eMax=sum(n[0::2])
oMax=sum(n[1::2])
tMax=0
while(max(n)!=0):
    tMax+=max(n)
    i=n.index(max(n))
    if i == 0:
        n[0],n[1] = 0,0
    elif i == len(n)-1:
        n[-2],n[-1]=0,0
    else:
        n[i],n[i+1],n[i-1] = 0,0,0
print(max([oMax,eMax,tMax]))
        
        
