'''n=int(input())
for i in range(n):
    n_days,a,b,c=map(int,input().split())
    a_l=n_days//a
    b_l=n_days//b
    c_l=n_days//c
    p,r=[],0
    d,w=[],0
    g,h=[],0
    for i in range(a_l):
        r=a*i
        p.append(r)
    for j in range(b_l):
        w=b*j
        d.append(w)
    for k in range(c_l):
        h=c*k
        g.append(h)
    t=p+d+g
    t = [x for x in t if x != 0]
    t=set(t)
print(t)
print(len(t))'''
'''n = int(input())

# Initialize an empty set to store unique flight times
flight_times = set()

for _ in range(n):
    n_days, a, b, c = map(int, input().split())

    # Calculate the maximum number of flights for each type
    a_l = n_days // a
    b_l = n_days // b
    c_l = n_days // c

    # Initialize lists to store flight times for each type
    a_times = [a * i for i in range(a_l + 1) if a * i <= n_days]
    b_times = [b * j for j in range(b_l + 1) if b * j <= n_days]
    c_times = [c * k for k in range(c_l + 1) if c * k <= n_days]

    # Combine flight times and remove 0
    combined_times = a_times + b_times + c_times
    combined_times = [x for x in combined_times if x != 0]

    # Update the set of flight times
    flight_times.update(combined_times)

# Print the unique flight times and the number of flights
flight_times_sorted = sorted(flight_times)
print(flight_times_sorted)  # Sorted for clarity
print(len(flight_times_sorted))'''
tcase=int(input())
tsum=0
for i in range(tcase):
    days,p,q,r=list(map(int,input().split()))
    for i in range(1,days+1):
        a=i % p
        b=i % q
        c=i % r
        if a==0 or b==0 or c==0:
            if a==0 and b==0:
                continue
            elif a==0 and c==0:
                continue
            elif b==0 and c==0:
                continue
            tsum+=1
    print(tsum)
   
        
        
    
        
