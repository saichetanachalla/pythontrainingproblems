#print("Hello","World",4,'a',sep='2',end='5',file="C:\\Users\\chinky\\Documents\\all python programs\\a.txt")
outdata = open("C:\\Users\\chinky\\Documents\\all python programs\\a.txt", "w")
print("Hello", file=outdata)
outdata.close()
